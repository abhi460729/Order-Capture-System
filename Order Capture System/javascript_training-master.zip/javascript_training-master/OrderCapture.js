
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var conn;
 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded({
     extended: true
 }));


// set port
app.listen(3000, function () {
    console.log('Node app is running on port 3000');
});
module.exports = app;

//CONNECT
function connects(response,host,user,password,db,port) 

{
   const mysql=require('mysql');
   conn=mysql.createConnection({
       host:host,
       user:user,
       password:password,
       database:db,
       port:port
   });    
   
conn.connect( (err) => {

if(err) response.send({"status":"0","message":"Error while connecting"});

else
response.send({"status":"1","message":"connected"});


}

);

}

app.post('/connect',(request,response)=>{
   var host=request.body.host;
   var user=request.body.user;
   var password=request.body.password;
   var db=request.body.db;
   var port=request.body.port;
   
   connects(response,host,user,password,db,port);
})



// DISCONNECT
app.get('/', function (request, response) {
    conn.end();
    return response.send({ status: 0})
});


// INSERT 

app.post('/insert',(request,response)=>{
 var tablename=request.body.tablename;
 var query="INSERT into "+tablename+" ( ";
 var len = Object.keys(request.body.values).length;
 Object.keys(request.body.values).forEach(function(k, index){
   query+=k;
   if(index!=len-1)
     query+=", "
 });
 query+=" ) VALUES ( ";
 Object.keys(request.body.values).forEach(function(k, index){
   query+="'"+request.body.values[k]+"'";
   if(index!=len-1)
     query+=", "
 });
 query+=" );";
 inserting(query,response);
});
 function inserting(query,response){
 conn.query(query,(err)=>{
   if (!err) {
    conn.query('SELECT LAST_INSERT_ID() as primary_key;',(err, rows)=>{
       
        var x = Object.values(rows[0]);
        response.send({"status": 1,
         "msg": "Data insertion successful!",
         "primary_key": x[0] 
       })
     });
   }
   else
     response.send({
       "status": 0,
       "msg": "Data insertion failed!",
       "error": err
     });
 });

}

//UPDATE

app.post('/update',(request,response)=> {
   var table_name= request.body.table_name;
   
   
   var columnValue = request.body.hasOwnProperty("condition");
   if (columnValue == false)
   {
      response.send({status:"0",message:"Update Failed."});
   }
   
    else
    {
    var condition= " WHERE "+request.body.condition;

   var values=request.body.values;
   updating(response,table_name,values,condition);
    }
})

function updating(response,table_name,values,condition)
{
   var len = Object.keys(values).length;
   console.log(len);
   var i=0;
   var query="UPDATE "+table_name+" SET "
   for(var key in values)
   {
       query=query+key+"= '"+values[key]+"'";
       i++;
       if(i!=len)
       query+=",";

   }
   query+=condition+";";
   
   conn.query(query,(err,result)=>{
       if(err) throw err;
       
       if(result.affectedrows!=0)
      {
           return response.send({status:"1"});
       
       }
           else
           return response.send({status:"0",message:'Update failed'});
   });
}

//connect



//SELECT

app.post('/select', (request, response) => {
 var tablename = request.body.tablename;
 var query = "SELECT ";
 var columnValue = request.body.hasOwnProperty("column");
 if (columnValue == false) {
   query += "* FROM " + tablename;
 }
 else {
   var len = Object.keys(request.body.column).length;
   Object.keys(request.body.column).forEach(function (k, index) {

     query += request.body.column[k].Name;
     if (index != len - 1)
       query += ", "
   });
   query += " FROM " + tablename;
 }
 var condition = request.body.hasOwnProperty("condition");
 if (condition != false) {
   query += " WHERE " + request.body.condition + ";";
 }
 else {
   query += ";";
 }
 select(query,response);
 function select(query, response) {
   conn.query(query, (err, results) => {
     if (!err) {
       response.send(results);
     } else {
       response.send({ "message": "Select could not be processed" });
     }
   });
 }
});